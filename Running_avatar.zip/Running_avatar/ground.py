import pygame
import os

pygame.init()

win = pygame.display.set_mode((500, 480))

pygame.display.set_caption("First Game")

# Function to load images with error handling
def load_image(image_path):
    try:
        return pygame.image.load(image_path)
    except pygame.error:
        print("Error loading image:", image_path)
        pygame.quit()
        quit()

# Load character images with error handling
char = load_image('standing_inPixio.png')

walkRight = [load_image('R1_inPixio.png'), load_image('R2_inPixio.png'), load_image('R3_inPixio.png'),
             load_image('R4_inPixio.png'), load_image('R5_inPixio.png'), load_image('R6_inPixio.png')]

walkLeft = [load_image('L1_inPixio.png'), load_image('L2_inPixio.png'), load_image('L3_inPixio.png'),
            load_image('L4_inPixio.png'), load_image('L5_inPixio.png'), load_image('L6_inPixio.png')]

bg = load_image('bg3.jpg')

# Load ground image
ground = load_image('ground_blocks.png')

clock = pygame.time.Clock()

x = 50
y = 295
width = 45
height = 55
vel = 5
isJump = False
jumpCount = 10
left = False
right = False
walkCount = 0

ground = pygame.transform.scale(ground, (500, 90))

# Create a single ground block with original dimensions
ground_block = pygame.Rect(0, 480 - ground.get_height(), ground.get_width(), ground.get_height())

# Function to get the next image in the animation
def get_next_image(image_list, current_index):
    return image_list[current_index % len(image_list)]

def redrawGameWindow(x, y, walkCount, left, right, isJump, jumpCount):
    win.blit(bg, (0, 0))

    # Draw the ground image with its original size
    win.blit(ground, ground_block.topleft)

    if left:
        image = get_next_image(walkLeft, walkCount)
        win.blit(image, (x, y))
    elif right:
        image = get_next_image(walkRight, walkCount)
        win.blit(image, (x, y))
    else:
        win.blit(char, (x, y))

    pygame.display.update()

run = True
while run:
    clock.tick(40)  # Adjust the animation speed

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and x > vel:
        x -= vel
        left = True
        right = False
        walkCount += 1
    elif keys[pygame.K_RIGHT] and x < 500 - width - vel:
        x += vel
        right = True
        left = False
        walkCount += 1
    else:
        right = False
        left = False
        walkCount = 0

    if not isJump:
        if keys[pygame.K_SPACE]:
            isJump = True
            right = False
            left = False
            walkCount = 0
    else:
        if jumpCount >= -10:
            neg = 1
            if jumpCount < 0:
                neg = -1
            y -= (jumpCount ** 2) * 0.5 * neg
            jumpCount -= 1
        else:
            isJump = False
            jumpCount = 10

    redrawGameWindow(x, y, walkCount, left, right, isJump, jumpCount)

pygame.quit()
